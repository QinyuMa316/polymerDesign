import os
from pathlib import Path
import pandas as pd
from rdkit import Chem, DataStructs
from rdkit.Chem import rdFingerprintGenerator


def mol_from_smiles(smiles):
    """与 ood_test_2.py 的解析方法一致。"""

    if pd.isna(smiles):
        return None

    try:
        return Chem.MolFromSmiles(str(smiles))
    except Exception:
        return None


def calculate_similarity(
    query_file,
    reference_file,
    query_column,
    reference_column,
    output_file
):
    """
    计算每个查询结构相对于参考数据集的最近邻相似度。

    Morgan 指纹：
        radius = 2
        fpSize = 2048

    相似度：
        最大 Tanimoto 相似度

    参考数据分块读取，适用于 PI1M 等较大的数据集。
    """

    # 1. 创建指纹生成器
    generator = rdFingerprintGenerator.GetMorganGenerator(
        radius=2,
        fpSize=2048
    )

    # 2. 读取待计算的结构
    query_df = pd.read_csv(
        query_file,
        encoding="utf-8-sig"
    )

    if query_column not in query_df.columns:
        raise ValueError(
            "查询文件中找不到列：" + query_column
        )

    if len(query_df) == 0:
        raise ValueError("查询文件没有数据行。")

    query_smiles = query_df[query_column].tolist()

    query_fps = []
    max_similarities = []
    nearest_smiles = []
    smiles_status = []

    valid_query_count = 0

    for smiles in query_smiles:
        mol = mol_from_smiles(smiles)

        if mol is None:
            query_fps.append(None)
            max_similarities.append(float("nan"))
            nearest_smiles.append("")
            smiles_status.append("invalid")

        else:
            fp = generator.GetFingerprint(mol)

            query_fps.append(fp)
            max_similarities.append(-1.0)
            nearest_smiles.append("")
            smiles_status.append("valid")

            valid_query_count += 1

    if valid_query_count == 0:
        raise ValueError("查询文件中没有有效 SMILES。")

    # 3. 分块读取参考数据
    # 不一次性保存 PI1M 的全部分子和指纹
    reference_reader = pd.read_csv(
        reference_file,
        encoding="utf-8-sig",
        chunksize=10000
    )

    total_reference_count = 0
    valid_reference_count = 0

    for chunk in reference_reader:

        if reference_column not in chunk.columns:
            raise ValueError(
                "参考文件中找不到列：" + reference_column
            )

        reference_fps = []
        reference_smiles = []

        for smiles in chunk[reference_column].tolist():
            mol = mol_from_smiles(smiles)

            if mol is not None:
                fp = generator.GetFingerprint(mol)

                reference_fps.append(fp)
                reference_smiles.append(str(smiles))

        total_reference_count += len(chunk)
        valid_reference_count += len(reference_fps)

        # 当前分块中没有有效结构时，跳过该分块
        if len(reference_fps) == 0:
            continue

        # 4. 计算查询结构与当前分块的相似度
        for i in range(len(query_fps)):

            if query_fps[i] is None:
                continue

            similarities = DataStructs.BulkTanimotoSimilarity(
                query_fps[i],
                reference_fps
            )

            current_max = max(similarities)

            # 更新在全部已读取参考结构中的最大相似度
            if current_max > max_similarities[i]:
                nearest_index = similarities.index(current_max)

                max_similarities[i] = current_max
                nearest_smiles[i] = reference_smiles[nearest_index]

        # print(
        #     "已读取参考结构：",
        #     total_reference_count,
        #     "；其中有效结构：",
        #     valid_reference_count
        # )

    if valid_reference_count == 0:
        raise ValueError("参考文件中没有有效 SMILES。")

    # 5. 保留原始数据，并添加结果列
    query_df["MaxTanimoto"] = max_similarities
    query_df["NearestReferenceSMILES"] = nearest_smiles
    query_df["SMILES_Status"] = smiles_status

    # 6. 保存结果
    output_dir = os.path.dirname(output_file)

    if output_dir != "":
        os.makedirs(output_dir, exist_ok=True)

    query_df.to_csv(
        output_file,
        index=False,
        encoding="utf-8-sig",
        float_format="%.12g"
    )

    # 7. 输出汇总信息
    valid_scores = query_df["MaxTanimoto"].dropna()

    # print("\n计算完成")
    print("查询结构总数：", len(query_df))
    print("有效查询结构：", valid_query_count)
    print("参考结构总数：", total_reference_count)
    print("有效参考结构：", valid_reference_count)

    print("\n最近邻相似度统计")
    print("最小值：", round(valid_scores.min(), 6))
    print("平均值：", round(valid_scores.mean(), 6))
    print("中位数：", round(valid_scores.median(), 6))
    print("最大值：", round(valid_scores.max(), 6))

    # print("\n结果保存至：", output_file)

    return query_df


if __name__ == "__main__":

    # 相对路径以脚本所在目录为基准，不受终端当前工作目录影响。
    script_dir = Path(__file__).resolve().parent

    # ========= 在这里修改文件路径和列名 =========

    # 待计算的 CSV 文件
    # 可以改成 polyimides_pred_prop_base_str_std.csv
    query_file = script_dir / "data/pareto_frontier_all.csv"
    # query_file = script_dir / "data/polyimides_scaffold_baseline.csv"


    # 参考数据集
    ref_file_list = [
                    # "data_train/PI1M_unique.csv",
                    "data_train/Tg_combined_unique.csv",
                    "data_train/EPS_combined_unique.csv"
                    ]
    for ref_file in ref_file_list:
        if not (script_dir / ref_file).exists():
            raise FileNotFoundError(f"参考文件不存在：{ref_file}")
        else:
            reference_file = script_dir / ref_file
            # reference_file = script_dir / "data_train/PI1M_unique.csv"

            # 两份文件各自的 SMILES 列名，可以不同
            query_column = "SMILES"             # "data/pareto_frontier_all.csv"
            # query_column = "scaffold SMILES"  # "data/polyimides_scaffold_baseline.csv"
            reference_column = "SMILES"

            # 输出结果路径
            output_file = script_dir / f"output/{query_file.stem}_{ref_file.split('/')[-1].split('.')[0]}_similarity.csv"

            print(f"\n结果保存至：{output_file}")

            # ========================================
            result = calculate_similarity(
                query_file,
                reference_file,
                query_column,
                reference_column,
                output_file
            )


"""
query_ref_simiarity

pareto_frontier_all.csv(query) 与 PI1M_unique.csv(ref) 的最近邻相似度计算结果

计算完成
查询结构总数： 144
有效查询结构： 144
参考结构总数： 988775
有效参考结构： 988775

最近邻相似度统计
最小值： 0.2625
平均值： 0.359428
中位数： 0.337355
最大值： 0.652174

结果保存至：pareto_frontier_all_Tg_combined_unique_similarity.csv
查询结构总数： 144
有效查询结构： 144
参考结构总数： 275
有效参考结构： 275

最近邻相似度统计
最小值： 0.16
平均值： 0.284971
中位数： 0.2625
最大值： 0.637931

结果保存至：pareto_frontier_all_EPS_combined_unique_similarity.csv
查询结构总数： 144
有效查询结构： 144
参考结构总数： 387
有效参考结构： 387

最近邻相似度统计
最小值： 0.16
平均值： 0.266787
中位数： 0.25894
最大值： 0.471698

结果保存至：polyimides_scaffold_baseline_PI1M_unique_similarity.csv
查询结构总数： 11
有效查询结构： 11
参考结构总数： 988775
有效参考结构： 988775

最近邻相似度统计
最小值： 0.625
平均值： 0.852797
中位数： 0.896552
最大值： 1.0

结果保存至：polyimides_scaffold_baseline_Tg_combined_unique_similarity.csv
查询结构总数： 11
有效查询结构： 11
参考结构总数： 275
有效参考结构： 275

最近邻相似度统计
最小值： 0.482759
平均值： 0.787681
中位数： 0.8125
最大值： 1.0

结果保存至：polyimides_scaffold_baseline_EPS_combined_unique_similarity.csv
查询结构总数： 11
有效查询结构： 11
参考结构总数： 387
有效参考结构： 387

最近邻相似度统计
最小值： 0.563636
平均值： 0.73724
中位数： 0.684211
最大值： 1.0
"""

