"""Stage 3: make publication-ready tables, a figure, and a results report.

Run ``cx_model_val_1.py`` and ``cx_model_val_2.py`` first, then run this file::

    python cx_model_val_3.py

No command-line arguments are required.  All outputs are written beneath
``cx_model_val``; no existing project file is modified.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


# ---------------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_ROOT / "cx_model_val"
FIGURE_DPI = 300
MODEL1_COLOR = "#2B6CB0"
MODEL2_COLOR = "#DD6B20"
RETENTION_COLOR = "#2F855A"
PARETO_COLOR = "#805AD5"
# ---------------------------------------------------------------------------


def add_identity_line(axis: plt.Axes, x: np.ndarray, y: np.ndarray) -> None:
    """Draw y=x and use identical limits on both axes."""
    lower = float(min(np.min(x), np.min(y)))
    upper = float(max(np.max(x), np.max(y)))
    padding = 0.04 * max(upper - lower, 1.0)
    lower -= padding
    upper += padding
    axis.plot([lower, upper], [lower, upper], "--", color="0.35", linewidth=1.0)
    axis.set_xlim(lower, upper)
    axis.set_ylim(lower, upper)


def make_figure(
    detail: pd.DataFrame, summary: pd.DataFrame, output_dir: Path
) -> None:
    """Plot paired changes, simultaneous retention, and Pareto stability."""
    candidates = detail.loc[detail["Record_Type"] == "candidate"].copy()
    retained = candidates["Retains_Simultaneous_Improvement"].astype(bool).to_numpy()
    figure, axes = plt.subplots(
        2, 2, figsize=(12.0, 9.2), constrained_layout=True
    )

    axis = axes[0, 0]
    x = candidates["Delta_k_Model1"].to_numpy(dtype=float)
    y = candidates["Delta_k_Model2"].to_numpy(dtype=float)
    axis.scatter(
        x[~retained],
        y[~retained],
        s=28,
        alpha=0.62,
        color="0.55",
        label="Other candidate",
    )
    axis.scatter(
        x[retained],
        y[retained],
        s=34,
        alpha=0.85,
        color=RETENTION_COLOR,
        label="Improves both in M1 and M2",
    )
    add_identity_line(axis, x, y)
    axis.axhline(0.0, color="0.75", linewidth=0.8)
    axis.axvline(0.0, color="0.75", linewidth=0.8)
    axis.set_xlabel(r"Model 1 paired change, $\Delta k$")
    axis.set_ylabel(r"Model 2 paired change, $\Delta k$")
    axis.set_title(r"(a) Baseline-relative change in $k$")
    axis.legend(frameon=False, fontsize=8, loc="best")

    axis = axes[0, 1]
    x = candidates["Delta_Tg_Model1_K"].to_numpy(dtype=float)
    y = candidates["Delta_Tg_Model2_K"].to_numpy(dtype=float)
    axis.scatter(x[~retained], y[~retained], s=28, alpha=0.62, color="0.55")
    axis.scatter(
        x[retained], y[retained], s=34, alpha=0.85, color=RETENTION_COLOR
    )
    add_identity_line(axis, x, y)
    axis.axhline(0.0, color="0.75", linewidth=0.8)
    axis.axvline(0.0, color="0.75", linewidth=0.8)
    axis.set_xlabel(r"Model 1 paired change, $\Delta T_g$ (K)")
    axis.set_ylabel(r"Model 2 paired change, $\Delta T_g$ (K)")
    axis.set_title(r"(b) Baseline-relative change in $T_g$")

    identifiers = summary["Backbone_ID"].astype(int).to_numpy()
    positions = np.arange(len(identifiers), dtype=float)
    width = 0.25
    axis = axes[1, 0]
    axis.bar(
        positions - width,
        summary["Fraction_Simultaneous_Model1"],
        width,
        color=MODEL1_COLOR,
        label="Model 1",
    )
    axis.bar(
        positions,
        summary["Fraction_Simultaneous_Model2"],
        width,
        color=MODEL2_COLOR,
        label="Model 2",
    )
    axis.bar(
        positions + width,
        summary["Fraction_Model1_Simultaneous_Retained_by_Model2"],
        width,
        color=RETENTION_COLOR,
        label="M1 improvements retained by M2",
    )
    axis.set_xticks(positions, identifiers)
    axis.set_ylim(0.0, 1.05)
    axis.set_xlabel("Backbone ID")
    axis.set_ylabel("Fraction")
    axis.set_title("(c) Simultaneous-improvement robustness")
    axis.legend(frameon=False, fontsize=8)

    axis = axes[1, 1]
    pareto_width = 0.34
    axis.bar(
        positions - pareto_width / 2,
        summary["Pareto_CandidatesOnly_Retention_M1_to_M2"],
        pareto_width,
        color=PARETO_COLOR,
        label="Candidates only (legacy)",
    )
    axis.bar(
        positions + pareto_width / 2,
        summary["Pareto_WithBaseline_Retention_M1_to_M2"],
        pareto_width,
        color="#B794F4",
        label="With baseline (primary)",
    )
    axis.set_xticks(positions, identifiers)
    axis.set_ylim(0.0, 1.05)
    axis.set_xlabel("Backbone ID")
    axis.set_ylabel("Fraction")
    axis.set_title("(d) Pareto-membership retention")
    axis.legend(frameon=False, fontsize=8)

    for axis in axes.flat:
        axis.spines["top"].set_visible(False)
        axis.spines["right"].set_visible(False)
        axis.tick_params(direction="out")

    figure.savefig(
        output_dir / "03_baseline_relative_robustness.png", dpi=FIGURE_DPI
    )
    figure.savefig(output_dir / "03_baseline_relative_robustness.pdf")
    plt.close(figure)


def percent(value: float, digits: int = 1) -> str:
    """Format a fraction as a percentage value without the percent sign."""
    if pd.isna(value):
        return "NA"
    return f"{100.0 * float(value):.{digits}f}"


def write_legacy_latex_table(legacy: pd.DataFrame, output_path: Path) -> None:
    """Write the previous SI cross-model table from regenerated results."""
    lines = [
        r"\begin{table}[!htb]",
        r"\renewcommand{\arraystretch}{1.2}",
        r"\caption{Cross-model comparison of property predictions for optimized polyimide "
        r"structures. Correlations quantify within-backbone agreement; MAD and RMSD quantify "
        r"differences between model predictions and are not errors relative to experiment.}",
        r"\label{tab:cross_model_evaluation}",
        r"\centering",
        r"\begin{tabular}{ccccccccc}",
        r"\toprule",
        r"ID & $k$ Pearson & $k$ Spearman & $k$ MAD & $k$ RMSD & "
        r"$T_g$ Pearson & $T_g$ Spearman & $T_g$ MAD (K) & $T_g$ RMSD (K) \\",
        r"\midrule",
    ]
    for _, row in legacy.sort_values("ID").iterrows():
        lines.append(
            f"{int(row['ID'])} & {row['EPS_Pearson']:.2f} & "
            f"{row['EPS_Spearman']:.2f} & {row['EPS_MeanAbsDiff']:.2f} & "
            f"{row['EPS_RMSEDiff']:.2f} & {row['Tg_Pearson']:.2f} & "
            f"{row['Tg_Spearman']:.2f} & {row['Tg_MeanAbsDiff']:.2f} & "
            f"{row['Tg_RMSEDiff']:.2f} \\\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}", ""])
    output_path.write_text("\n".join(lines), encoding="utf-8")


def write_baseline_latex_table(
    summary: pd.DataFrame, overall: pd.Series, output_path: Path
) -> None:
    """Write a concise SI table that directly follows the review request."""
    lines = [
        r"\begin{table*}[!htb]",
        r"\centering",
        r"\caption{Baseline-relative cross-model robustness of the optimized candidates. "
        r"Paired changes are candidate minus the corresponding unmodified backbone; lower "
        r"$k$ and higher $T_g$ are favorable. Both M2 is the number simultaneously improved "
        r"under Model 2. Retained is conditional on simultaneous improvement under Model 1. "
        r"Pareto stability is calculated after including the matching baseline.}",
        r"\label{tab:baseline_relative_cross_model}",
        r"\begin{tabular}{crrrrrrrrr}",
        r"\toprule",
        r"ID & $N$ & $\overline{\Delta k}_{M1}$ & $\overline{\Delta k}_{M2}$ & "
        r"$\overline{\Delta T_g}_{M1}$ (K) & $\overline{\Delta T_g}_{M2}$ (K) & "
        r"Both M1 & Both M2 & Retained (\%) & Pareto retention (\%) \\",
        r"\midrule",
    ]
    for _, row in summary.sort_values("Backbone_ID").iterrows():
        lines.append(
            f"{int(row['Backbone_ID'])} & {int(row['N_Candidates'])} & "
            f"{row['Mean_Delta_k_Model1']:.3f} & {row['Mean_Delta_k_Model2']:.3f} & "
            f"{row['Mean_Delta_Tg_Model1_K']:.1f} & "
            f"{row['Mean_Delta_Tg_Model2_K']:.1f} & "
            f"{int(row['N_Simultaneous_Model1'])} & "
            f"{int(row['N_Simultaneous_Model2'])} & "
            f"{percent(row['Fraction_Model1_Simultaneous_Retained_by_Model2'])} & "
            f"{percent(row['Pareto_WithBaseline_Retention_M1_to_M2'])} \\\\"
        )
    lines.extend(
        [
            r"\midrule",
            f"Overall & {int(overall['N_Candidates'])} & "
            f"{overall['Mean_Delta_k_Model1']:.3f} & "
            f"{overall['Mean_Delta_k_Model2']:.3f} & "
            f"{overall['Mean_Delta_Tg_Model1_K']:.1f} & "
            f"{overall['Mean_Delta_Tg_Model2_K']:.1f} & "
            f"{int(overall['N_Simultaneous_Model1'])} & "
            f"{int(overall['N_Simultaneous_Model2'])} & "
            f"{percent(overall['Fraction_Model1_Simultaneous_Retained_by_Model2'])} & "
            f"{percent(overall['Pareto_WithBaseline_Retention_M1_to_M2'])} \\\\ ",
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{table*}",
            "",
        ]
    )
    output_path.write_text("\n".join(lines), encoding="utf-8")


def markdown_backbone_table(summary: pd.DataFrame) -> str:
    """Make a compact per-backbone table for the generated report."""
    lines = [
        "| ID | N | Mean Δk M1 | Mean Δk M2 | Mean ΔTg M1 (K) | "
        "Mean ΔTg M2 (K) | M1 both | M2 both | Retained | Pareto retention |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for _, row in summary.sort_values("Backbone_ID").iterrows():
        lines.append(
            f"| {int(row['Backbone_ID'])} | {int(row['N_Candidates'])} | "
            f"{row['Mean_Delta_k_Model1']:.3f} | {row['Mean_Delta_k_Model2']:.3f} | "
            f"{row['Mean_Delta_Tg_Model1_K']:.1f} | "
            f"{row['Mean_Delta_Tg_Model2_K']:.1f} | "
            f"{int(row['N_Simultaneous_Model1'])} | "
            f"{int(row['N_Simultaneous_Model2'])} | "
            f"{percent(row['Fraction_Model1_Simultaneous_Retained_by_Model2'])}% | "
            f"{percent(row['Pareto_WithBaseline_Retention_M1_to_M2'])}% |"
        )
    return "\n".join(lines)


def write_report(
    summary: pd.DataFrame,
    overall: pd.Series,
    legacy_audit: pd.DataFrame,
    output_path: Path,
) -> None:
    """Write a plain-language audit report with no hidden interpretation."""
    n_candidates = int(overall["N_Candidates"])
    model1_count = int(overall["N_Simultaneous_Model1"])
    model2_count = int(overall["N_Simultaneous_Model2"])
    retained_count = int(overall["N_Model1_Simultaneous_Retained_by_Model2"])
    model1_backbones = int((summary["N_Simultaneous_Model1"] > 0).sum())
    model2_backbones = int((summary["N_Simultaneous_Model2"] > 0).sum())
    defined_retention = summary[
        "Fraction_Model1_Simultaneous_Retained_by_Model2"
    ].dropna()
    legacy_matches = bool(
        legacy_audit["Matches_Within_Tolerance"].fillna(False).all()
    )
    max_legacy_difference = float(
        legacy_audit["Max_Abs_Numeric_Difference"].dropna().max()
    )

    report = f"""# Baseline-relative cross-model robustness results

## Data and reproduction check

The analysis contains {n_candidates} final NSGA-II candidates from 11 polyimide backbones and the
11 matching unmodified backbones. The ID mapping uses the first-occurrence unique `scaffold`
values in `polyDesign_data/data_modification/polyimides_pred_prop_base_str_std.csv` and is checked
against the GA's saved `resultCompareSeed2025/base_polymers.csv` file.

The regenerated legacy candidate-only outputs {'match' if legacy_matches else 'do not match'} both
files in `cross_model_validation` at the declared numerical tolerance. The largest numeric
difference is {max_legacy_difference:.6g}; candidate keys and Model-2 nondominated labels are also
checked.

## Definitions

For each model, paired changes are candidate minus the corresponding unmodified backbone. A
simultaneous improvement requires `Delta k < 0` and `Delta Tg > 0`. Pareto membership is recomputed
separately for each backbone after adding its unmodified baseline to the candidate set. All
classifications use unrounded predictions. Model-1 columns use saved optimization-time predictions;
Model-2 columns use fresh checkpoint predictions.

## Main numerical results

- Model 1 identifies {model1_count}/{n_candidates}
  ({percent(overall['Fraction_Simultaneous_Model1'])}%) candidates as simultaneously improved;
  Model 2 identifies {model2_count}/{n_candidates}
  ({percent(overall['Fraction_Simultaneous_Model2'])}%).
- Of the {model1_count} Model-1 simultaneous improvements, {retained_count}
  ({percent(overall['Fraction_Model1_Simultaneous_Retained_by_Model2'])}%) remain simultaneous
  improvements under Model 2. This is {percent(overall['Fraction_AllCandidates_Simultaneous_in_Both'])}%
  of all candidates.
- At least one simultaneous improvement occurs for {model1_backbones}/11 backbones under Model 1
  and {model2_backbones}/11 under Model 2. Per-backbone conditional retention ranges from
  {percent(defined_retention.min())}% to {percent(defined_retention.max())}%.
- Mean paired changes are `Delta k = {overall['Mean_Delta_k_Model1']:.3f}` and
  `Delta Tg = {overall['Mean_Delta_Tg_Model1_K']:.1f} K` under Model 1, versus
  `Delta k = {overall['Mean_Delta_k_Model2']:.3f}` and
  `Delta Tg = {overall['Mean_Delta_Tg_Model2_K']:.1f} K` under Model 2.
- Baseline-subtracted changes have Pearson correlations of
  `r = {overall['Delta_k_Pearson_M1_M2']:.3f}` for `Delta k` and
  `r = {overall['Delta_Tg_Pearson_M1_M2']:.3f}` for `Delta Tg`.
- With the matching baseline included, aggregate Pareto retention is
  {int(overall['N_Pareto_WithBaseline_Intersection'])}/
  {int(overall['N_Pareto_WithBaseline_Model1'])}
  ({percent(overall['Pareto_WithBaseline_Retention_M1_to_M2'])}%), and aggregate Jaccard similarity
  is {percent(overall['Pareto_WithBaseline_Jaccard'])}%. Candidate-only Pareto retention (the old
  definition) is {percent(overall['Pareto_CandidatesOnly_Retention_M1_to_M2'])}%.

## Calibration-offset test

The mean signed Model-2-minus-Model-1 shifts of the baselines are
{overall['Mean_Baseline_k_Shift_M2_minus_M1']:.3f} for `k` and
{overall['Mean_Baseline_Tg_Shift_M2_minus_M1_K']:.1f} K for `Tg`. After matching and subtracting
each baseline, the mean Model-2-minus-Model-1 difference-in-differences is
{overall['Mean_DeltaDelta_k_M2_minus_M1']:.3f} for `k` and
{overall['Mean_DeltaDelta_Tg_M2_minus_M1_K']:.1f} K for `Tg`, with mean absolute residuals of
{overall['MAE_DeltaDelta_k']:.3f} and {overall['MAE_DeltaDelta_Tg_K']:.1f} K. A purely additive,
backbone-level calibration offset would cancel and leave near-zero residuals. The offset therefore
explains only part of the cross-model difference, especially for `Tg`.

## Per-backbone results

{markdown_backbone_table(summary)}

## Interpretation boundary

The 31 candidates that improve both properties under both models are the defensible cross-model
robust subset. The calculation does not support a universal robustness claim for all 144
candidates, and it is not experimental or higher-fidelity physical validation. Manuscript wording
should therefore be narrowed to the retained subset and explicitly describe the remaining model
sensitivity.
"""
    output_path.write_text(report, encoding="utf-8")


def main() -> None:
    """Read stage-2 results and write all presentation-ready artifacts."""
    required = {
        "detail": OUTPUT_DIR / "02_paired_changes_and_membership.csv",
        "summary": OUTPUT_DIR / "02_baseline_relative_summary_by_backbone.csv",
        "overall": OUTPUT_DIR / "02_overall_robustness_summary.csv",
        "legacy": OUTPUT_DIR / "02_legacy_by_backbone.csv",
        "legacy_audit": OUTPUT_DIR / "02_legacy_reproduction_check.csv",
    }
    missing = [path for path in required.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError(
            "Run cx_model_val_1.py and cx_model_val_2.py first. Missing: "
            + ", ".join(str(path) for path in missing)
        )
    if FIGURE_DPI < 72:
        raise ValueError("FIGURE_DPI must be at least 72.")

    detail = pd.read_csv(required["detail"], encoding="utf-8-sig")
    summary = pd.read_csv(required["summary"], encoding="utf-8-sig")
    overall = pd.read_csv(required["overall"], encoding="utf-8-sig").iloc[0]
    legacy = pd.read_csv(required["legacy"], encoding="utf-8-sig")
    legacy_audit = pd.read_csv(required["legacy_audit"], encoding="utf-8-sig")

    make_figure(detail, summary, OUTPUT_DIR)
    write_legacy_latex_table(legacy, OUTPUT_DIR / "03_legacy_cross_model_table.tex")
    write_baseline_latex_table(
        summary, overall, OUTPUT_DIR / "03_baseline_relative_table.tex"
    )
    write_report(summary, overall, legacy_audit, OUTPUT_DIR / "03_results_report.md")
    print(f"Wrote figure, LaTeX tables, and report under: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
