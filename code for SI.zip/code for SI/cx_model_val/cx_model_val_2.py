"""Stage 2: reproduce the old comparison and add baseline-relative tests.

Run ``cx_model_val_1.py`` first, then run this file directly::

    python cx_model_val_2.py

No command-line arguments are required.  This stage calculates exactly the
minimum analyses requested by the reviewer:

1. paired candidate-minus-baseline changes in k and Tg under both models;
2. the fraction retaining simultaneous improvement (lower k and higher Tg);
3. Pareto-membership stability, both candidate-only and baseline-inclusive;
4. difference-in-differences diagnostics for the calibration-offset claim.

The earlier candidate-only cross-model table is also regenerated and compared
against ``cross_model_validation`` so that the old and new analyses share the
same structures and Model-2 predictions.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr


# ---------------------------------------------------------------------------
# CONFIGURATION: the script runs as-is after cx_model_val_1.py.
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
INPUT_FILE = PROJECT_ROOT / "cx_model_val" / "01_all_structure_predictions.csv"
OUTPUT_DIR = PROJECT_ROOT / "cx_model_val"
LEGACY_REFERENCE_DIR = PROJECT_ROOT / "cross_model_validation"
LEGACY_REPRODUCTION_TOLERANCE = 1.0e-3
NUMERIC_TOLERANCE = 1.0e-12
# ---------------------------------------------------------------------------


def safe_ratio(numerator: int | float, denominator: int | float) -> float:
    """Divide while representing an undefined zero-denominator ratio as NaN."""
    return float(numerator / denominator) if denominator else float("nan")


def safe_correlation(x: Iterable[float], y: Iterable[float], method: str) -> float:
    """Calculate a correlation, returning NaN for too-short/constant inputs."""
    first = np.asarray(list(x), dtype=float)
    second = np.asarray(list(y), dtype=float)
    if (
        len(first) < 2
        or np.ptp(first) <= NUMERIC_TOLERANCE
        or np.ptp(second) <= NUMERIC_TOLERANCE
    ):
        return float("nan")
    if method == "pearson":
        return float(pearsonr(first, second).statistic)
    if method == "spearman":
        return float(spearmanr(first, second).statistic)
    raise ValueError(f"Unknown correlation method: {method}")


def nondominated_mask(k: Iterable[float], tg: Iterable[float]) -> np.ndarray:
    """Return Pareto membership for the objectives minimize k / maximize Tg."""
    k_values = np.asarray(list(k), dtype=float)
    tg_values = np.asarray(list(tg), dtype=float)
    if len(k_values) != len(tg_values):
        raise ValueError("k and Tg arrays must have the same length.")
    if not np.isfinite(k_values).all() or not np.isfinite(tg_values).all():
        raise ValueError("Pareto inputs must be finite.")

    mask = np.ones(len(k_values), dtype=bool)
    for index in range(len(k_values)):
        no_worse = (k_values <= k_values[index] + NUMERIC_TOLERANCE) & (
            tg_values >= tg_values[index] - NUMERIC_TOLERANCE
        )
        strictly_better = (k_values < k_values[index] - NUMERIC_TOLERANCE) | (
            tg_values > tg_values[index] + NUMERIC_TOLERANCE
        )
        if np.any(no_worse & strictly_better):
            mask[index] = False
    return mask


def set_metrics(first: set, second: set) -> dict[str, float | int]:
    """Summarize stability between a Model-1 set and a Model-2 set."""
    intersection = first.intersection(second)
    union = first.union(second)
    return {
        "N_Intersection": len(intersection),
        "Retention_M1_to_M2": safe_ratio(len(intersection), len(first)),
        "Precision_M2_vs_M1": safe_ratio(len(intersection), len(second)),
        "Jaccard": safe_ratio(len(intersection), len(union)),
    }


def validate_input(frame: pd.DataFrame) -> None:
    """Check that stage 1 supplied a complete, unambiguous evaluation set."""
    required = {
        "Backbone_ID",
        "Record_Type",
        "Candidate_Index",
        "SMILES",
        "k_Model1",
        "Tg_Model1_K",
        "k_Model2",
        "Tg_Model2_K",
    }
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Prediction input is missing columns: {sorted(missing)}")
    unexpected = set(frame["Record_Type"]).difference({"baseline", "candidate"})
    if unexpected:
        raise ValueError(f"Unexpected Record_Type values: {sorted(unexpected)}")

    baseline_counts = frame.groupby("Backbone_ID")["Record_Type"].apply(
        lambda values: int((values == "baseline").sum())
    )
    if not (baseline_counts == 1).all():
        raise ValueError(
            "Each backbone must have exactly one baseline; found "
            f"{baseline_counts.to_dict()}."
        )
    candidate_counts = frame.groupby("Backbone_ID")["Record_Type"].apply(
        lambda values: int((values == "candidate").sum())
    )
    if not (candidate_counts > 0).all():
        raise ValueError(
            f"Each backbone must have candidates; found {candidate_counts.to_dict()}."
        )

    numeric = ["k_Model1", "Tg_Model1_K", "k_Model2", "Tg_Model2_K"]
    if not np.isfinite(frame[numeric].to_numpy(dtype=float)).all():
        raise ValueError("Prediction input contains missing or non-finite predictions.")


def build_legacy_predictions(candidates: pd.DataFrame) -> pd.DataFrame:
    """Recreate the row-level file used by the previous SI analysis."""
    legacy = pd.DataFrame(
        {
            "SMILES": candidates["SMILES"].astype(str),
            "Tg": candidates["Tg_Model1_K"].astype(float),
            "EPS": candidates["k_Model1"].astype(float),
            "ID": candidates["Backbone_ID"].astype(int),
            "EPS_Model1": candidates["k_Model1"].astype(float),
            "Tg_Model1": candidates["Tg_Model1_K"].astype(float),
            "EPS_Model2": candidates["k_Model2"].astype(float),
            "Tg_Model2": candidates["Tg_Model2_K"].astype(float),
        }
    ).reset_index(drop=True)
    legacy["EPS_Diff_M2_M1"] = legacy["EPS_Model2"] - legacy["EPS_Model1"]
    legacy["Tg_Diff_M2_M1"] = legacy["Tg_Model2"] - legacy["Tg_Model1"]
    legacy["EPS_AbsDiff"] = legacy["EPS_Diff_M2_M1"].abs()
    legacy["Tg_AbsDiff"] = legacy["Tg_Diff_M2_M1"].abs()
    legacy["NonDominated_Model2"] = False
    for _, indexes in legacy.groupby("ID", sort=True).groups.items():
        group = legacy.loc[indexes]
        legacy.loc[indexes, "NonDominated_Model2"] = nondominated_mask(
            group["EPS_Model2"], group["Tg_Model2"]
        )
    return legacy


def build_legacy_summary(legacy: pd.DataFrame) -> pd.DataFrame:
    """Recreate the 11-row cross-model table already reported in the SI."""
    rows: list[dict[str, float | int]] = []
    for backbone_id, group in legacy.groupby("ID", sort=True):
        model1_mask = nondominated_mask(group["EPS_Model1"], group["Tg_Model1"])
        model2_mask = nondominated_mask(group["EPS_Model2"], group["Tg_Model2"])
        eps_difference = group["EPS_Model2"].to_numpy() - group["EPS_Model1"].to_numpy()
        tg_difference = group["Tg_Model2"].to_numpy() - group["Tg_Model1"].to_numpy()
        rows.append(
            {
                "ID": int(backbone_id),
                "N_Candidates": len(group),
                "N_NonDominated_Model1_Check": int(model1_mask.sum()),
                "N_NonDominated_Model2": int(model2_mask.sum()),
                "Retention_Model2": float(model2_mask.sum() / len(group)),
                "EPS_Pearson": safe_correlation(
                    group["EPS_Model1"], group["EPS_Model2"], "pearson"
                ),
                "EPS_Spearman": safe_correlation(
                    group["EPS_Model1"], group["EPS_Model2"], "spearman"
                ),
                "EPS_MeanAbsDiff": float(np.mean(np.abs(eps_difference))),
                "EPS_RMSEDiff": float(np.sqrt(np.mean(eps_difference**2))),
                "Tg_Pearson": safe_correlation(
                    group["Tg_Model1"], group["Tg_Model2"], "pearson"
                ),
                "Tg_Spearman": safe_correlation(
                    group["Tg_Model1"], group["Tg_Model2"], "spearman"
                ),
                "Tg_MeanAbsDiff": float(np.mean(np.abs(tg_difference))),
                "Tg_RMSEDiff": float(np.sqrt(np.mean(tg_difference**2))),
            }
        )
    return pd.DataFrame(rows)


def boolean_array(series: pd.Series) -> np.ndarray:
    """Convert a CSV boolean column safely, including string-valued columns."""
    if pd.api.types.is_bool_dtype(series):
        return series.to_numpy(dtype=bool)
    normalized = series.astype(str).str.strip().str.lower()
    allowed = {"true", "false"}
    unexpected = set(normalized).difference(allowed)
    if unexpected:
        raise ValueError(f"Unexpected boolean values: {sorted(unexpected)}")
    return normalized.eq("true").to_numpy(dtype=bool)


def compare_artifact(
    generated: pd.DataFrame,
    reference_path: Path,
    key_columns: list[str],
    numeric_columns: list[str],
    boolean_columns: list[str],
    tolerance: float,
) -> dict[str, object]:
    """Compare a regenerated legacy artifact with the existing result."""
    result: dict[str, object] = {
        "Artifact": reference_path.name,
        "Reference_Present": reference_path.is_file(),
        "Generated_Rows": len(generated),
        "Reference_Rows": np.nan,
        "Keys_Match": False,
        "Max_Abs_Numeric_Difference": np.nan,
        "Boolean_Mismatches": np.nan,
        "Matches_Within_Tolerance": False,
        "Tolerance": tolerance,
    }
    if not reference_path.is_file():
        return result

    reference = pd.read_csv(reference_path)
    result["Reference_Rows"] = len(reference)
    required = set(key_columns + numeric_columns + boolean_columns)
    missing_generated = required.difference(generated.columns)
    missing_reference = required.difference(reference.columns)
    if missing_generated or missing_reference:
        result["Note"] = (
            f"missing generated={sorted(missing_generated)}; "
            f"missing reference={sorted(missing_reference)}"
        )
        return result

    left = generated[key_columns + numeric_columns + boolean_columns].copy()
    right = reference[key_columns + numeric_columns + boolean_columns].copy()
    left = left.sort_values(key_columns).reset_index(drop=True)
    right = right.sort_values(key_columns).reset_index(drop=True)
    keys_match = left.shape == right.shape and left[key_columns].equals(
        right[key_columns]
    )
    result["Keys_Match"] = bool(keys_match)
    if not keys_match:
        return result

    left_numeric = left[numeric_columns].to_numpy(dtype=float)
    right_numeric = right[numeric_columns].to_numpy(dtype=float)
    differences = np.abs(left_numeric - right_numeric)
    finite_differences = differences[np.isfinite(differences)]
    max_difference = float(finite_differences.max()) if finite_differences.size else 0.0
    nonfinite_pattern_matches = np.array_equal(
        ~np.isfinite(left_numeric), ~np.isfinite(right_numeric)
    )
    boolean_mismatches = sum(
        int((boolean_array(left[column]) != boolean_array(right[column])).sum())
        for column in boolean_columns
    )
    result["Max_Abs_Numeric_Difference"] = max_difference
    result["Boolean_Mismatches"] = boolean_mismatches
    result["Matches_Within_Tolerance"] = bool(
        nonfinite_pattern_matches
        and max_difference <= tolerance
        and boolean_mismatches == 0
    )
    return result


def legacy_reproduction_audit(
    legacy_predictions: pd.DataFrame,
    legacy_summary: pd.DataFrame,
) -> pd.DataFrame:
    """Check both existing cross-model CSV files at one declared tolerance."""
    prediction_numeric = [
        "Tg",
        "EPS",
        "EPS_Model1",
        "Tg_Model1",
        "EPS_Model2",
        "Tg_Model2",
        "EPS_Diff_M2_M1",
        "Tg_Diff_M2_M1",
        "EPS_AbsDiff",
        "Tg_AbsDiff",
    ]
    summary_numeric = [
        "N_Candidates",
        "N_NonDominated_Model1_Check",
        "N_NonDominated_Model2",
        "Retention_Model2",
        "EPS_Pearson",
        "EPS_Spearman",
        "EPS_MeanAbsDiff",
        "EPS_RMSEDiff",
        "Tg_Pearson",
        "Tg_Spearman",
        "Tg_MeanAbsDiff",
        "Tg_RMSEDiff",
    ]
    rows = [
        compare_artifact(
            legacy_predictions,
            LEGACY_REFERENCE_DIR / "optimized_PI_Model1_vs_Model2_predictions.csv",
            ["ID", "SMILES"],
            prediction_numeric,
            ["NonDominated_Model2"],
            LEGACY_REPRODUCTION_TOLERANCE,
        ),
        compare_artifact(
            legacy_summary,
            LEGACY_REFERENCE_DIR / "Model1_vs_Model2_by_backbone.csv",
            ["ID"],
            summary_numeric,
            [],
            LEGACY_REPRODUCTION_TOLERANCE,
        ),
    ]
    return pd.DataFrame(rows)


def add_paired_changes_and_membership(frame: pd.DataFrame) -> pd.DataFrame:
    """Add the reviewer-requested paired changes and membership labels."""
    chunks: list[pd.DataFrame] = []
    for _, group in frame.groupby("Backbone_ID", sort=True):
        group = group.copy().reset_index(drop=True)
        baseline = group.loc[group["Record_Type"] == "baseline"].iloc[0]
        candidates = group["Record_Type"] == "candidate"

        for model in ("Model1", "Model2"):
            k_column = f"k_{model}"
            tg_column = f"Tg_{model}_K"
            group[f"Delta_k_{model}"] = (
                group[k_column] - float(baseline[k_column])
            )
            group[f"Delta_Tg_{model}_K"] = (
                group[tg_column] - float(baseline[tg_column])
            )
            group[f"Improves_k_{model}"] = group[f"Delta_k_{model}"] < 0.0
            group[f"Improves_Tg_{model}"] = group[f"Delta_Tg_{model}_K"] > 0.0
            group[f"Simultaneous_Improvement_{model}"] = (
                group[f"Improves_k_{model}"] & group[f"Improves_Tg_{model}"]
            )

            # Primary reviewer-facing definition: include the unmodified base.
            group[f"Pareto_WithBaseline_{model}"] = nondominated_mask(
                group[k_column], group[tg_column]
            )
            # Retain the old candidate-only definition for continuity with the SI.
            group[f"Pareto_CandidatesOnly_{model}"] = False
            group.loc[candidates, f"Pareto_CandidatesOnly_{model}"] = (
                nondominated_mask(
                    group.loc[candidates, k_column],
                    group.loc[candidates, tg_column],
                )
            )

        group["Retains_Simultaneous_Improvement"] = (
            group["Simultaneous_Improvement_Model1"]
            & group["Simultaneous_Improvement_Model2"]
        )
        # Difference-in-differences removes a backbone-specific additive offset.
        group["DeltaDelta_k_M2_minus_M1"] = (
            group["Delta_k_Model2"] - group["Delta_k_Model1"]
        )
        group["DeltaDelta_Tg_M2_minus_M1_K"] = (
            group["Delta_Tg_Model2_K"] - group["Delta_Tg_Model1_K"]
        )
        group["Pareto_WithBaseline_Status_Agreement"] = (
            group["Pareto_WithBaseline_Model1"]
            == group["Pareto_WithBaseline_Model2"]
        )
        group["Pareto_CandidatesOnly_Status_Agreement"] = (
            group["Pareto_CandidatesOnly_Model1"]
            == group["Pareto_CandidatesOnly_Model2"]
        )
        chunks.append(group)
    return pd.concat(chunks, ignore_index=True)


def cross_model_agreement(candidates: pd.DataFrame) -> pd.DataFrame:
    """Calculate the previous candidate-ranking agreement metrics."""
    rows: list[dict[str, float | int]] = []
    for backbone_id, group in candidates.groupby("Backbone_ID", sort=True):
        row: dict[str, float | int] = {
            "Backbone_ID": int(backbone_id),
            "N_Candidates": len(group),
        }
        for target, model1_column, model2_column in (
            ("k", "k_Model1", "k_Model2"),
            ("Tg", "Tg_Model1_K", "Tg_Model2_K"),
        ):
            first = group[model1_column].to_numpy(dtype=float)
            second = group[model2_column].to_numpy(dtype=float)
            difference = second - first
            row[f"{target}_Pearson"] = safe_correlation(first, second, "pearson")
            row[f"{target}_Spearman"] = safe_correlation(first, second, "spearman")
            row[f"{target}_MeanAbsDiff"] = float(np.mean(np.abs(difference)))
            row[f"{target}_RMSEDiff"] = float(np.sqrt(np.mean(difference**2)))
        rows.append(row)
    return pd.DataFrame(rows)


def baseline_predictions(detail: pd.DataFrame) -> pd.DataFrame:
    """Return Model-1 and Model-2 values for the 11 unmodified backbones."""
    baseline = detail.loc[detail["Record_Type"] == "baseline"].copy()
    baseline["k_Shift_M2_minus_M1"] = baseline["k_Model2"] - baseline["k_Model1"]
    baseline["Tg_Shift_M2_minus_M1_K"] = (
        baseline["Tg_Model2_K"] - baseline["Tg_Model1_K"]
    )
    columns = [
        "Backbone_ID",
        "SMILES",
        "k_Model1",
        "Tg_Model1_K",
        "k_Model2",
        "Tg_Model2_K",
        "k_Shift_M2_minus_M1",
        "Tg_Shift_M2_minus_M1_K",
        "Pareto_WithBaseline_Model1",
        "Pareto_WithBaseline_Model2",
    ]
    return baseline[columns].sort_values("Backbone_ID").reset_index(drop=True)


def summarize_by_backbone(detail: pd.DataFrame) -> pd.DataFrame:
    """Summarize paired changes, improvement retention, and Pareto stability."""
    rows: list[dict[str, float | int | bool]] = []
    for backbone_id, all_rows in detail.groupby("Backbone_ID", sort=True):
        candidates = all_rows.loc[all_rows["Record_Type"] == "candidate"].copy()
        baseline = all_rows.loc[all_rows["Record_Type"] == "baseline"].iloc[0]
        candidate_index = candidates["Candidate_Index"].astype(int)

        candidate_only_m1 = set(
            candidate_index[candidates["Pareto_CandidatesOnly_Model1"].astype(bool)]
        )
        candidate_only_m2 = set(
            candidate_index[candidates["Pareto_CandidatesOnly_Model2"].astype(bool)]
        )
        with_baseline_m1 = set(
            candidate_index[candidates["Pareto_WithBaseline_Model1"].astype(bool)]
        )
        with_baseline_m2 = set(
            candidate_index[candidates["Pareto_WithBaseline_Model2"].astype(bool)]
        )
        candidate_only_stability = set_metrics(candidate_only_m1, candidate_only_m2)
        with_baseline_stability = set_metrics(with_baseline_m1, with_baseline_m2)

        model1_simultaneous = candidates["Simultaneous_Improvement_Model1"].astype(bool)
        model2_simultaneous = candidates["Simultaneous_Improvement_Model2"].astype(bool)
        retained = model1_simultaneous & model2_simultaneous

        row: dict[str, float | int | bool] = {
            "Backbone_ID": int(backbone_id),
            "N_Candidates": len(candidates),
            "Baseline_k_Model1": float(baseline["k_Model1"]),
            "Baseline_Tg_Model1_K": float(baseline["Tg_Model1_K"]),
            "Baseline_k_Model2": float(baseline["k_Model2"]),
            "Baseline_Tg_Model2_K": float(baseline["Tg_Model2_K"]),
            "Baseline_k_Shift_M2_minus_M1": float(
                baseline["k_Model2"] - baseline["k_Model1"]
            ),
            "Baseline_Tg_Shift_M2_minus_M1_K": float(
                baseline["Tg_Model2_K"] - baseline["Tg_Model1_K"]
            ),
        }
        for model in ("Model1", "Model2"):
            delta_k = candidates[f"Delta_k_{model}"]
            delta_tg = candidates[f"Delta_Tg_{model}_K"]
            improves_k = candidates[f"Improves_k_{model}"].astype(bool)
            improves_tg = candidates[f"Improves_Tg_{model}"].astype(bool)
            simultaneous = candidates[f"Simultaneous_Improvement_{model}"].astype(bool)
            row.update(
                {
                    f"Mean_Delta_k_{model}": float(delta_k.mean()),
                    f"Median_Delta_k_{model}": float(delta_k.median()),
                    f"Mean_Delta_Tg_{model}_K": float(delta_tg.mean()),
                    f"Median_Delta_Tg_{model}_K": float(delta_tg.median()),
                    f"N_Improves_k_{model}": int(improves_k.sum()),
                    f"Fraction_Improves_k_{model}": float(improves_k.mean()),
                    f"N_Improves_Tg_{model}": int(improves_tg.sum()),
                    f"Fraction_Improves_Tg_{model}": float(improves_tg.mean()),
                    f"N_Simultaneous_{model}": int(simultaneous.sum()),
                    f"Fraction_Simultaneous_{model}": float(simultaneous.mean()),
                }
            )

        row.update(
            {
                "N_Model1_Simultaneous_Retained_by_Model2": int(retained.sum()),
                "Fraction_Model1_Simultaneous_Retained_by_Model2": safe_ratio(
                    int(retained.sum()), int(model1_simultaneous.sum())
                ),
                "Simultaneous_Status_Agreement": float(
                    (model1_simultaneous == model2_simultaneous).mean()
                ),
                "Mean_DeltaDelta_k_M2_minus_M1": float(
                    candidates["DeltaDelta_k_M2_minus_M1"].mean()
                ),
                "MAE_DeltaDelta_k": float(
                    candidates["DeltaDelta_k_M2_minus_M1"].abs().mean()
                ),
                "Mean_DeltaDelta_Tg_M2_minus_M1_K": float(
                    candidates["DeltaDelta_Tg_M2_minus_M1_K"].mean()
                ),
                "MAE_DeltaDelta_Tg_K": float(
                    candidates["DeltaDelta_Tg_M2_minus_M1_K"].abs().mean()
                ),
                "N_Pareto_CandidatesOnly_Model1": len(candidate_only_m1),
                "N_Pareto_CandidatesOnly_Model2": len(candidate_only_m2),
                "N_Pareto_CandidatesOnly_Intersection": candidate_only_stability[
                    "N_Intersection"
                ],
                "Pareto_CandidatesOnly_Retention_M1_to_M2": (
                    candidate_only_stability["Retention_M1_to_M2"]
                ),
                "Pareto_CandidatesOnly_Jaccard": candidate_only_stability["Jaccard"],
                "N_Pareto_WithBaseline_Model1": len(with_baseline_m1),
                "N_Pareto_WithBaseline_Model2": len(with_baseline_m2),
                "N_Pareto_WithBaseline_Intersection": with_baseline_stability[
                    "N_Intersection"
                ],
                "Pareto_WithBaseline_Retention_M1_to_M2": (
                    with_baseline_stability["Retention_M1_to_M2"]
                ),
                "Pareto_WithBaseline_Precision_M2_vs_M1": (
                    with_baseline_stability["Precision_M2_vs_M1"]
                ),
                "Pareto_WithBaseline_Jaccard": with_baseline_stability["Jaccard"],
                "Pareto_WithBaseline_Membership_Agreement": float(
                    candidates["Pareto_WithBaseline_Status_Agreement"].mean()
                ),
                "Baseline_Pareto_Model1": bool(baseline["Pareto_WithBaseline_Model1"]),
                "Baseline_Pareto_Model2": bool(baseline["Pareto_WithBaseline_Model2"]),
            }
        )
        rows.append(row)
    return pd.DataFrame(rows)


def selected_candidate_keys(candidates: pd.DataFrame, column: str) -> set[tuple[int, int]]:
    """Return stable (backbone, candidate) keys selected by one boolean column."""
    selected = candidates.loc[candidates[column].astype(bool)]
    return set(
        zip(
            selected["Backbone_ID"].astype(int),
            selected["Candidate_Index"].astype(int),
        )
    )


def summarize_overall(detail: pd.DataFrame, by_backbone: pd.DataFrame) -> pd.DataFrame:
    """Create one overall row with micro- and macro-averaged results."""
    candidates = detail.loc[detail["Record_Type"] == "candidate"].copy()
    baselines = detail.loc[detail["Record_Type"] == "baseline"].copy()
    model1_simultaneous = candidates["Simultaneous_Improvement_Model1"].astype(bool)
    model2_simultaneous = candidates["Simultaneous_Improvement_Model2"].astype(bool)
    retained = model1_simultaneous & model2_simultaneous

    result: dict[str, float | int] = {
        "N_Backbones": int(detail["Backbone_ID"].nunique()),
        "N_Candidates": len(candidates),
        "Mean_Baseline_k_Shift_M2_minus_M1": float(
            (baselines["k_Model2"] - baselines["k_Model1"]).mean()
        ),
        "Mean_Baseline_Tg_Shift_M2_minus_M1_K": float(
            (baselines["Tg_Model2_K"] - baselines["Tg_Model1_K"]).mean()
        ),
    }
    for model in ("Model1", "Model2"):
        result[f"Mean_Delta_k_{model}"] = float(
            candidates[f"Delta_k_{model}"].mean()
        )
        result[f"Median_Delta_k_{model}"] = float(
            candidates[f"Delta_k_{model}"].median()
        )
        result[f"Mean_Delta_Tg_{model}_K"] = float(
            candidates[f"Delta_Tg_{model}_K"].mean()
        )
        result[f"Median_Delta_Tg_{model}_K"] = float(
            candidates[f"Delta_Tg_{model}_K"].median()
        )
        for status in ("Improves_k", "Improves_Tg", "Simultaneous_Improvement"):
            values = candidates[f"{status}_{model}"].astype(bool)
            label = "Simultaneous" if status == "Simultaneous_Improvement" else status
            result[f"N_{label}_{model}"] = int(values.sum())
            result[f"Fraction_{label}_{model}"] = float(values.mean())

    result.update(
        {
            "N_Model1_Simultaneous_Retained_by_Model2": int(retained.sum()),
            "Fraction_Model1_Simultaneous_Retained_by_Model2": safe_ratio(
                int(retained.sum()), int(model1_simultaneous.sum())
            ),
            "Fraction_AllCandidates_Simultaneous_in_Both": float(retained.mean()),
            "Simultaneous_Status_Agreement": float(
                (model1_simultaneous == model2_simultaneous).mean()
            ),
            "Mean_DeltaDelta_k_M2_minus_M1": float(
                candidates["DeltaDelta_k_M2_minus_M1"].mean()
            ),
            "Median_DeltaDelta_k_M2_minus_M1": float(
                candidates["DeltaDelta_k_M2_minus_M1"].median()
            ),
            "MAE_DeltaDelta_k": float(
                candidates["DeltaDelta_k_M2_minus_M1"].abs().mean()
            ),
            "RMSE_DeltaDelta_k": float(
                np.sqrt(np.mean(candidates["DeltaDelta_k_M2_minus_M1"] ** 2))
            ),
            "Mean_DeltaDelta_Tg_M2_minus_M1_K": float(
                candidates["DeltaDelta_Tg_M2_minus_M1_K"].mean()
            ),
            "Median_DeltaDelta_Tg_M2_minus_M1_K": float(
                candidates["DeltaDelta_Tg_M2_minus_M1_K"].median()
            ),
            "MAE_DeltaDelta_Tg_K": float(
                candidates["DeltaDelta_Tg_M2_minus_M1_K"].abs().mean()
            ),
            "RMSE_DeltaDelta_Tg_K": float(
                np.sqrt(np.mean(candidates["DeltaDelta_Tg_M2_minus_M1_K"] ** 2))
            ),
            "Delta_k_Pearson_M1_M2": safe_correlation(
                candidates["Delta_k_Model1"], candidates["Delta_k_Model2"], "pearson"
            ),
            "Delta_k_Spearman_M1_M2": safe_correlation(
                candidates["Delta_k_Model1"], candidates["Delta_k_Model2"], "spearman"
            ),
            "Delta_Tg_Pearson_M1_M2": safe_correlation(
                candidates["Delta_Tg_Model1_K"],
                candidates["Delta_Tg_Model2_K"],
                "pearson",
            ),
            "Delta_Tg_Spearman_M1_M2": safe_correlation(
                candidates["Delta_Tg_Model1_K"],
                candidates["Delta_Tg_Model2_K"],
                "spearman",
            ),
            "MacroMean_Fraction_Simultaneous_Model1": float(
                by_backbone["Fraction_Simultaneous_Model1"].mean()
            ),
            "MacroMean_Fraction_Simultaneous_Model2": float(
                by_backbone["Fraction_Simultaneous_Model2"].mean()
            ),
            "MacroMean_Conditional_Simultaneous_Retention": float(
                by_backbone[
                    "Fraction_Model1_Simultaneous_Retained_by_Model2"
                ].mean()
            ),
            "MacroMean_Pareto_WithBaseline_Jaccard": float(
                by_backbone["Pareto_WithBaseline_Jaccard"].mean()
            ),
            "MacroMean_Pareto_WithBaseline_Retention": float(
                by_backbone["Pareto_WithBaseline_Retention_M1_to_M2"].mean()
            ),
            "MacroMean_Pareto_CandidatesOnly_Retention": float(
                by_backbone["Pareto_CandidatesOnly_Retention_M1_to_M2"].mean()
            ),
        }
    )

    for prefix in ("Pareto_CandidatesOnly", "Pareto_WithBaseline"):
        first = selected_candidate_keys(candidates, f"{prefix}_Model1")
        second = selected_candidate_keys(candidates, f"{prefix}_Model2")
        metrics = set_metrics(first, second)
        result[f"N_{prefix}_Model1"] = len(first)
        result[f"N_{prefix}_Model2"] = len(second)
        result[f"N_{prefix}_Intersection"] = int(metrics["N_Intersection"])
        result[f"{prefix}_Retention_M1_to_M2"] = float(
            metrics["Retention_M1_to_M2"]
        )
        result[f"{prefix}_Precision_M2_vs_M1"] = float(
            metrics["Precision_M2_vs_M1"]
        )
        result[f"{prefix}_Jaccard"] = float(metrics["Jaccard"])

    return pd.DataFrame([result])


def reviewer_summary(by_backbone: pd.DataFrame) -> pd.DataFrame:
    """Create a compact table containing only the reviewer's requested fields."""
    columns = [
        "Backbone_ID",
        "N_Candidates",
        "Mean_Delta_k_Model1",
        "Mean_Delta_k_Model2",
        "Mean_Delta_Tg_Model1_K",
        "Mean_Delta_Tg_Model2_K",
        "N_Simultaneous_Model1",
        "N_Simultaneous_Model2",
        "N_Model1_Simultaneous_Retained_by_Model2",
        "Fraction_Model1_Simultaneous_Retained_by_Model2",
        "N_Pareto_WithBaseline_Model1",
        "N_Pareto_WithBaseline_Model2",
        "N_Pareto_WithBaseline_Intersection",
        "Pareto_WithBaseline_Retention_M1_to_M2",
        "Pareto_WithBaseline_Jaccard",
    ]
    return by_backbone[columns].copy()


def write_definitions(output_path: Path) -> None:
    """Write plain-language definitions next to the machine-readable results."""
    text = """# Cross-model robustness metric definitions

- Objectives: minimize dielectric constant `k` and maximize glass-transition temperature `Tg`.
- Model 1 values: saved optimization-time predictions (the values used by NSGA-II).
- Model 2 values: fresh predictions for every baseline and candidate.
- Paired changes: `Delta k = k(candidate) - k(matching baseline)` and
  `Delta Tg = Tg(candidate) - Tg(matching baseline)`, calculated within each model.
- Simultaneous improvement: `Delta k < 0` and `Delta Tg > 0`, using unrounded values.
- Conditional simultaneous-improvement retention: the number improving both properties under both
  models divided by the number improving both under Model 1.
- Candidate-only Pareto membership: nondominance among optimized candidates of one backbone. This
  is the definition in the previous cross-model analysis.
- Baseline-inclusive Pareto membership: nondominance after adding the matching unmodified backbone
  to that backbone's candidate set. This is the primary baseline-relative definition.
- Pareto retention: Model-1/Model-2 membership intersection divided by the Model-1 set size.
- Pareto precision: membership intersection divided by the Model-2 set size.
- Pareto Jaccard: membership intersection divided by membership union.
- `DeltaDelta`: Model-2 paired change minus Model-1 paired change. A purely additive,
  backbone-specific calibration offset would cancel and give a value near zero.
- Cross-model differences are not errors relative to experimental measurements.
"""
    output_path.write_text(text, encoding="utf-8")


def main() -> None:
    """Run stage 2 and write all old/new statistical results."""
    if not INPUT_FILE.is_file():
        raise FileNotFoundError(
            f"Missing {INPUT_FILE}. Run cx_model_val_1.py before cx_model_val_2.py."
        )
    if not OUTPUT_DIR.is_dir():
        raise FileNotFoundError(
            f"Missing output directory {OUTPUT_DIR}; run cx_model_val_1.py first."
        )
    if LEGACY_REPRODUCTION_TOLERANCE < 0:
        raise ValueError("LEGACY_REPRODUCTION_TOLERANCE must be non-negative.")

    frame = pd.read_csv(INPUT_FILE, encoding="utf-8-sig")
    validate_input(frame)
    candidates = frame.loc[frame["Record_Type"] == "candidate"].copy()

    legacy_predictions = build_legacy_predictions(candidates)
    legacy_summary = build_legacy_summary(legacy_predictions)
    legacy_audit = legacy_reproduction_audit(legacy_predictions, legacy_summary)

    detail = add_paired_changes_and_membership(frame)
    detail_candidates = detail.loc[detail["Record_Type"] == "candidate"].copy()
    robust_candidates = detail_candidates.loc[
        detail_candidates["Retains_Simultaneous_Improvement"].astype(bool)
    ].copy()
    agreement = cross_model_agreement(detail_candidates)
    baselines = baseline_predictions(detail)
    by_backbone = summarize_by_backbone(detail)
    overall = summarize_overall(detail, by_backbone)
    compact_reviewer = reviewer_summary(by_backbone)

    outputs = {
        "02_legacy_candidate_predictions.csv": legacy_predictions,
        "02_legacy_by_backbone.csv": legacy_summary,
        "02_legacy_reproduction_check.csv": legacy_audit,
        "02_paired_changes_and_membership.csv": detail,
        "02_cross_model_robust_candidates.csv": robust_candidates,
        "02_baseline_predictions_by_backbone.csv": baselines,
        "02_cross_model_agreement_by_backbone.csv": agreement,
        "02_baseline_relative_summary_by_backbone.csv": by_backbone,
        "02_overall_robustness_summary.csv": overall,
        "02_reviewer_summary_by_backbone.csv": compact_reviewer,
    }
    for filename, table in outputs.items():
        table.to_csv(OUTPUT_DIR / filename, index=False, encoding="utf-8-sig")
    write_definitions(OUTPUT_DIR / "02_metric_definitions.md")

    row = overall.iloc[0]
    console_summary = {
        "n_candidates": int(row["N_Candidates"]),
        "model1_simultaneous": int(row["N_Simultaneous_Model1"]),
        "model2_simultaneous": int(row["N_Simultaneous_Model2"]),
        "retained_from_model1": int(
            row["N_Model1_Simultaneous_Retained_by_Model2"]
        ),
        "conditional_simultaneous_retention": float(
            row["Fraction_Model1_Simultaneous_Retained_by_Model2"]
        ),
        "pareto_with_baseline_retention": float(
            row["Pareto_WithBaseline_Retention_M1_to_M2"]
        ),
        "pareto_with_baseline_jaccard": float(
            row["Pareto_WithBaseline_Jaccard"]
        ),
        "legacy_outputs_match": bool(
            legacy_audit["Matches_Within_Tolerance"].fillna(False).all()
        ),
    }
    print(f"Wrote legacy and baseline-relative results under: {OUTPUT_DIR}")
    print(json.dumps(console_summary, indent=2))


if __name__ == "__main__":
    main()
