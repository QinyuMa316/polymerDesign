"""Stage 1: evaluate every optimized candidate and its matching baseline.

Run this file directly from PyCharm, or from the project root with the Python
interpreter that contains PyTorch, PyTorch Geometric, RDKit, NumPy, and pandas::

    python cx_model_val_1.py

No command-line arguments are required.  Paths and the few user-adjustable
settings are collected in the CONFIGURATION section below.  Existing project
files are only read; generated files are written to ``cx_model_val``.
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import platform
import sys
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
import torch
from rdkit import Chem, rdBase
from torch_geometric.loader import DataLoader


# ---------------------------------------------------------------------------
# CONFIGURATION: the script runs as-is for the present project.
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
BASE_SOURCE = (
    PROJECT_ROOT
    / "polyDesign_data"
    / "data_modification"
    / "polyimides_pred_prop_base_str_std.csv"
)
CANDIDATE_ROOT = PROJECT_ROOT / "resultCompareSeed2025"
MODEL1_DIR = PROJECT_ROOT / "models_polymer"
MODEL2_DIR = PROJECT_ROOT / "models_polymer_2"
OUTPUT_DIR = PROJECT_ROOT / "cx_model_val"
BATCH_SIZE = 64
DEVICE = "auto"  # "auto", "cpu", "cuda", or an explicit device such as "cuda:0"
MODEL1_REPRODUCTION_TOLERANCE = 1.0e-3
EXPECTED_BACKBONES = 11
# ---------------------------------------------------------------------------


if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from MolOpt.GATmodel import GATModel  # noqa: E402
from MolOpt.molDataLoader import MolDataset  # noqa: E402


def require_file(path: Path, description: str) -> None:
    """Raise a clear error when a required input is unavailable."""
    if not path.is_file():
        raise FileNotFoundError(f"Missing {description}: {path}")


def resolve_device(requested: str) -> torch.device:
    """Resolve the requested inference device without changing model results."""
    if requested == "auto":
        requested = "cuda" if torch.cuda.is_available() else "cpu"
    device = torch.device(requested)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("A CUDA device was requested, but CUDA is unavailable.")
    return device


def unique_checkpoint(folder: Path, target: str) -> Path:
    """Return the single trained checkpoint for one property and model."""
    matches = sorted(folder.glob(f"best_model_{target}_*.pth"))
    if len(matches) != 1:
        raise FileNotFoundError(
            f"Expected exactly one {target} checkpoint in {folder}, found "
            f"{len(matches)}: {[str(path) for path in matches]}"
        )
    return matches[0]


def sha256(path: Path) -> str:
    """Calculate an input checksum for reproducibility records."""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_smiles(smiles: str) -> str:
    """Parse and canonicalize a polymer SMILES string with RDKit."""
    molecule = Chem.MolFromSmiles(smiles)
    if molecule is None:
        raise ValueError(f"RDKit could not parse SMILES: {smiles}")
    return Chem.MolToSmiles(molecule, canonical=True)


def backbone_id_from_path(path: Path) -> int:
    """Extract the integer ID from an NSGA-II_idN directory name."""
    try:
        return int(path.parent.name.rsplit("id", 1)[1])
    except (IndexError, ValueError) as exc:
        raise ValueError(f"Cannot obtain a backbone ID from {path}") from exc


def load_baselines(base_source: Path, candidate_root: Path) -> pd.DataFrame:
    """Map the 11 source scaffolds to the exact Model-1 GA baselines.

    The GA code used first-occurrence unique values from the ``scaffold``
    column and predicted them before optimization.  Those exact predictions
    were saved in ``resultCompareSeed2025/base_polymers.csv``.  Both sources
    are checked here so that ID-to-backbone mapping cannot silently drift.
    """
    require_file(base_source, "base-polymer source table")
    saved_path = candidate_root / "base_polymers.csv"
    require_file(saved_path, "saved GA baseline table")

    source = pd.read_csv(base_source)
    source_required = {"SMILES", "EPS", "Tg", "scaffold"}
    missing = source_required.difference(source.columns)
    if missing:
        raise ValueError(f"{base_source} is missing columns: {sorted(missing)}")

    # This reproduces list(dict.fromkeys(df['scaffold'])) in polymerDesignGA.py.
    unique_scaffolds = source["scaffold"].astype(str).drop_duplicates().tolist()
    if len(unique_scaffolds) != EXPECTED_BACKBONES:
        raise ValueError(
            f"Expected {EXPECTED_BACKBONES} unique scaffolds in {base_source}, "
            f"found {len(unique_scaffolds)}."
        )

    saved = pd.read_csv(saved_path)
    saved_required = {"id", "smiles", "eps", "tg"}
    missing = saved_required.difference(saved.columns)
    if missing:
        raise ValueError(f"{saved_path} is missing columns: {sorted(missing)}")
    if saved["id"].duplicated().any():
        raise ValueError(f"Duplicate backbone IDs were found in {saved_path}.")

    observed_ids = sorted(saved["id"].astype(int).tolist())
    expected_ids = list(range(EXPECTED_BACKBONES))
    if observed_ids != expected_ids:
        raise ValueError(
            f"Unexpected IDs in {saved_path}: expected {expected_ids}, "
            f"found {observed_ids}."
        )

    records: list[dict[str, object]] = []
    for backbone_id, scaffold in enumerate(unique_scaffolds):
        saved_row = saved.loc[saved["id"].astype(int) == backbone_id].iloc[0]
        saved_smiles = str(saved_row["smiles"])
        if canonical_smiles(scaffold) != canonical_smiles(saved_smiles):
            raise ValueError(
                "The source scaffold and saved GA baseline differ for "
                f"backbone {backbone_id}: {scaffold!r} != {saved_smiles!r}."
            )
        source_rows = source.index[
            source["scaffold"].astype(str) == scaffold
        ].tolist()
        records.append(
            {
                "Backbone_ID": backbone_id,
                "Record_Type": "baseline",
                "Candidate_Index": -1,
                "SMILES": scaffold,
                "k_Model1_Source": float(saved_row["eps"]),
                "Tg_Model1_Source_K": float(saved_row["tg"]),
                "Source_File": str(saved_path.relative_to(PROJECT_ROOT)),
                "Source_Record": f"id={backbone_id}",
                "Base_Source_Rows": ";".join(str(index) for index in source_rows),
            }
        )
    return pd.DataFrame(records)


def load_candidates(candidate_root: Path, baseline_ids: Sequence[int]) -> pd.DataFrame:
    """Read the saved final NSGA-II front for every backbone."""
    paths = sorted(
        candidate_root.glob("NSGA-II_id*/pareto_frontier.jsonl"),
        key=backbone_id_from_path,
    )
    candidate_ids = [backbone_id_from_path(path) for path in paths]
    if candidate_ids != list(baseline_ids):
        raise ValueError(
            "Backbone IDs differ between the baselines and Pareto files: "
            f"baselines={list(baseline_ids)}, candidates={candidate_ids}."
        )

    records: list[dict[str, object]] = []
    for path in paths:
        backbone_id = backbone_id_from_path(path)
        candidate_index = 0
        with path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                item = json.loads(line)
                required = {"smiles", "eps", "tg"}
                missing = required.difference(item)
                if missing:
                    raise ValueError(
                        f"{path} line {line_number} lacks fields: {sorted(missing)}"
                    )
                records.append(
                    {
                        "Backbone_ID": backbone_id,
                        "Record_Type": "candidate",
                        "Candidate_Index": candidate_index,
                        "SMILES": str(item["smiles"]),
                        "k_Model1_Source": float(item["eps"]),
                        "Tg_Model1_Source_K": float(item["tg"]),
                        "Source_File": str(path.relative_to(PROJECT_ROOT)),
                        "Source_Record": f"line={line_number}",
                        "Base_Source_Rows": "",
                    }
                )
                candidate_index += 1
        if candidate_index == 0:
            raise ValueError(f"No candidates were found in {path}.")
    return pd.DataFrame(records)


def load_all_records(base_source: Path, candidate_root: Path) -> pd.DataFrame:
    """Load and validate the complete baseline/candidate evaluation set."""
    baselines = load_baselines(base_source, candidate_root)
    candidates = load_candidates(
        candidate_root, baselines["Backbone_ID"].astype(int).tolist()
    )
    frame = pd.concat([baselines, candidates], ignore_index=True)

    invalid = [
        smiles
        for smiles in frame["SMILES"].astype(str)
        if Chem.MolFromSmiles(smiles) is None
    ]
    if invalid:
        raise ValueError(
            f"RDKit could not parse {len(invalid)} structures, including {invalid[:3]}."
        )

    keys = ["Backbone_ID", "Record_Type", "Candidate_Index"]
    if frame.duplicated(subset=keys, keep=False).any():
        raise ValueError("Duplicate backbone/type/index keys were found in the inputs.")
    candidate_rows = frame["Record_Type"] == "candidate"
    if frame.loc[candidate_rows].duplicated(
        subset=["Backbone_ID", "SMILES"], keep=False
    ).any():
        raise ValueError("Duplicate candidate SMILES were found within a backbone.")
    return frame


def load_model(checkpoint_path: Path, device: torch.device) -> GATModel:
    """Build the training-time GAT architecture and load one checkpoint."""
    model = GATModel(
        num_node_features=7,
        num_edge_features=6,
        hidden_dim=128,
        num_heads=4,
        dropout=0.2,
        num_layers=3,
    )
    # The checkpoints are trusted local project artifacts.  Explicitly setting
    # weights_only=False preserves compatibility with their dictionary format.
    try:
        checkpoint = torch.load(
            checkpoint_path, map_location=device, weights_only=False
        )
    except TypeError:  # Compatibility with older PyTorch versions.
        checkpoint = torch.load(checkpoint_path, map_location=device)
    if not isinstance(checkpoint, dict) or "model_state_dict" not in checkpoint:
        raise ValueError(f"Checkpoint has no model_state_dict: {checkpoint_path}")
    model.load_state_dict(checkpoint["model_state_dict"], strict=True)
    return model.to(device).eval()


def predict(
    smiles: Sequence[str],
    checkpoint_path: Path,
    device: torch.device,
    batch_size: int,
) -> list[float]:
    """Predict one property for a fixed, ordered list of structures."""
    model = load_model(checkpoint_path, device)
    dataset = MolDataset(list(smiles), [0.0] * len(smiles), contrastive=False)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    predictions: list[float] = []
    with torch.inference_mode():
        for batch in loader:
            output, _ = model(batch.to(device))
            predictions.extend(output.detach().cpu().numpy().astype(float).tolist())
    if len(predictions) != len(smiles):
        raise RuntimeError(
            f"Predicted {len(predictions)} values for {len(smiles)} structures."
        )
    values = np.asarray(predictions, dtype=float)
    if not np.isfinite(values).all():
        raise RuntimeError(f"Non-finite predictions came from {checkpoint_path}.")
    return values.tolist()


def package_version(name: str) -> str:
    """Return a package version without making provenance collection fragile."""
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return "not-installed"


def write_provenance(
    output_path: Path,
    device: torch.device,
    checkpoints: dict[str, Path],
    inputs: Iterable[Path],
    frame: pd.DataFrame,
    audit: dict[str, float],
) -> None:
    """Record model, input, software, and mapping details needed to reproduce."""
    payload = {
        "purpose": "Model-1/Model-2 evaluation of PI baselines and optimized candidates",
        "objective_directions": {"k": "minimize", "Tg": "maximize"},
        "model1_values_used_in_analysis": (
            "saved optimization-time values; recomputed values are an audit"
        ),
        "model2_values_used_in_analysis": "fresh predictions from Model-2 checkpoints",
        "base_mapping": (
            "first-occurrence unique source-table scaffolds, checked against "
            "resultCompareSeed2025/base_polymers.csv"
        ),
        "project_root": str(PROJECT_ROOT),
        "base_source": str(BASE_SOURCE),
        "candidate_root": str(CANDIDATE_ROOT),
        "output_dir": str(OUTPUT_DIR),
        "device": str(device),
        "batch_size": BATCH_SIZE,
        "model1_reproduction_tolerance": MODEL1_REPRODUCTION_TOLERANCE,
        "counts": {
            "backbones": int(frame["Backbone_ID"].nunique()),
            "baselines": int((frame["Record_Type"] == "baseline").sum()),
            "candidates": int((frame["Record_Type"] == "candidate").sum()),
        },
        "model1_recomputation_audit": audit,
        "software": {
            "python": platform.python_version(),
            "torch": torch.__version__,
            "torch-geometric": package_version("torch-geometric"),
            "rdkit": rdBase.rdkitVersion,
            "numpy": np.__version__,
            "pandas": pd.__version__,
        },
        "checkpoints": {
            name: {"path": str(path), "sha256": sha256(path)}
            for name, path in checkpoints.items()
        },
        "inputs": {
            str(path): sha256(path)
            for path in sorted(set(inputs), key=lambda item: str(item))
        },
    }
    with output_path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


def main() -> None:
    """Run stage 1 with the configuration declared at the top of this file."""
    if BATCH_SIZE < 1:
        raise ValueError("BATCH_SIZE must be at least 1.")
    if MODEL1_REPRODUCTION_TOLERANCE < 0:
        raise ValueError("MODEL1_REPRODUCTION_TOLERANCE must be non-negative.")

    device = resolve_device(DEVICE)
    frame = load_all_records(BASE_SOURCE, CANDIDATE_ROOT)
    checkpoints = {
        "Model1_k": unique_checkpoint(MODEL1_DIR, "EPS"),
        "Model1_Tg": unique_checkpoint(MODEL1_DIR, "Tg"),
        "Model2_k": unique_checkpoint(MODEL2_DIR, "EPS"),
        "Model2_Tg": unique_checkpoint(MODEL2_DIR, "Tg"),
    }

    smiles = frame["SMILES"].astype(str).tolist()
    print(f"Using device: {device}")
    print(f"Evaluating {len(smiles)} structures with four checkpoints ...")
    frame["k_Model1_Recomputed"] = predict(
        smiles, checkpoints["Model1_k"], device, BATCH_SIZE
    )
    frame["Tg_Model1_Recomputed_K"] = predict(
        smiles, checkpoints["Model1_Tg"], device, BATCH_SIZE
    )
    frame["k_Model2"] = predict(
        smiles, checkpoints["Model2_k"], device, BATCH_SIZE
    )
    frame["Tg_Model2_K"] = predict(
        smiles, checkpoints["Model2_Tg"], device, BATCH_SIZE
    )

    frame["k_Model1_Recomputed_minus_Source"] = (
        frame["k_Model1_Recomputed"] - frame["k_Model1_Source"]
    )
    frame["Tg_Model1_Recomputed_minus_Source_K"] = (
        frame["Tg_Model1_Recomputed_K"] - frame["Tg_Model1_Source_K"]
    )
    audit = {
        "max_abs_k_difference": float(
            frame["k_Model1_Recomputed_minus_Source"].abs().max()
        ),
        "max_abs_Tg_difference_K": float(
            frame["Tg_Model1_Recomputed_minus_Source_K"].abs().max()
        ),
    }
    if max(audit.values()) > MODEL1_REPRODUCTION_TOLERANCE:
        raise RuntimeError(
            "Fresh Model-1 predictions do not reproduce the saved GA values: "
            f"{audit}; tolerance={MODEL1_REPRODUCTION_TOLERANCE}."
        )

    # The exact optimization-time values are primary for Model 1.  The fresh
    # predictions above independently verify the checkpoints and inputs.
    frame["k_Model1"] = frame["k_Model1_Source"]
    frame["Tg_Model1_K"] = frame["Tg_Model1_Source_K"]
    frame["k_Model2_minus_Model1"] = frame["k_Model2"] - frame["k_Model1"]
    frame["Tg_Model2_minus_Model1_K"] = (
        frame["Tg_Model2_K"] - frame["Tg_Model1_K"]
    )

    record_order = frame["Record_Type"].map({"baseline": 0, "candidate": 1})
    frame = (
        frame.assign(_Record_Order=record_order)
        .sort_values(["Backbone_ID", "_Record_Order", "Candidate_Index"])
        .drop(columns="_Record_Order")
        .reset_index(drop=True)
    )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    predictions_path = OUTPUT_DIR / "01_all_structure_predictions.csv"
    frame.to_csv(predictions_path, index=False, encoding="utf-8-sig")

    input_paths = [
        BASE_SOURCE,
        CANDIDATE_ROOT / "base_polymers.csv",
        *CANDIDATE_ROOT.glob("NSGA-II_id*/pareto_frontier.jsonl"),
    ]
    write_provenance(
        OUTPUT_DIR / "01_prediction_provenance.json",
        device,
        checkpoints,
        input_paths,
        frame,
        audit,
    )

    print(f"Wrote: {predictions_path}")
    print(
        "Model-1 reproduction audit passed: "
        f"max |k difference|={audit['max_abs_k_difference']:.3g}; "
        f"max |Tg difference|={audit['max_abs_Tg_difference_K']:.3g} K"
    )
    print(
        f"Evaluated {(frame['Record_Type'] == 'baseline').sum()} baselines and "
        f"{(frame['Record_Type'] == 'candidate').sum()} candidates with Model 2."
    )


if __name__ == "__main__":
    main()
