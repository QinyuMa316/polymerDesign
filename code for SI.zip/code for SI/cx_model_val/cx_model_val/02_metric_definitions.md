# Cross-model robustness metric definitions

- Objectives: minimize dielectric constant `k` and maximize glass-transition temperature `Tg`.
- Model 1 values: saved optimization-time predictions (the values used by NSGA-II).
- Model 2 values: fresh predictions for every baseline and candidate.
- Paired changes: `Delta k = k(candidate) - k(matching baseline)` and
  `Delta Tg = Tg(candidate) - Tg(matching baseline)`, calculated within each model.
- Simultaneous improvement: `Delta k < 0` and `Delta Tg > 0`, using unrounded values.
- Conditional simultaneous-improvement retention: the number improving both properties under both
  models divided by the number improving both under Model 1.
- Candidate-only Pareto membership: nondominance among optimized candidates of one backbone. This
  is the definition in the previous cross-model analysis.
- Baseline-inclusive Pareto membership: nondominance after adding the matching unmodified backbone
  to that backbone's candidate set. This is the primary baseline-relative definition.
- Pareto retention: Model-1/Model-2 membership intersection divided by the Model-1 set size.
- Pareto precision: membership intersection divided by the Model-2 set size.
- Pareto Jaccard: membership intersection divided by membership union.
- `DeltaDelta`: Model-2 paired change minus Model-1 paired change. A purely additive,
  backbone-specific calibration offset would cancel and give a value near zero.
- Cross-model differences are not errors relative to experimental measurements.
