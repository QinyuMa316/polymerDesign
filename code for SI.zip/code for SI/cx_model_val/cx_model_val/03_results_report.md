# Baseline-relative cross-model robustness results

## Data and reproduction check

The analysis contains 144 final NSGA-II candidates from 11 polyimide backbones and the
11 matching unmodified backbones. The ID mapping uses the first-occurrence unique `scaffold`
values in `polyDesign_data/data_modification/polyimides_pred_prop_base_str_std.csv` and is checked
against the GA's saved `resultCompareSeed2025/base_polymers.csv` file.

The regenerated legacy candidate-only outputs match both
files in `cross_model_validation` at the declared numerical tolerance. The largest numeric
difference is 3.05176e-05; candidate keys and Model-2 nondominated labels are also
checked.

## Definitions

For each model, paired changes are candidate minus the corresponding unmodified backbone. A
simultaneous improvement requires `Delta k < 0` and `Delta Tg > 0`. Pareto membership is recomputed
separately for each backbone after adding its unmodified baseline to the candidate set. All
classifications use unrounded predictions. Model-1 columns use saved optimization-time predictions;
Model-2 columns use fresh checkpoint predictions.

## Main numerical results

- Model 1 identifies 114/144
  (79.2%) candidates as simultaneously improved;
  Model 2 identifies 31/144
  (21.5%).
- Of the 114 Model-1 simultaneous improvements, 31
  (27.2%) remain simultaneous
  improvements under Model 2. This is 21.5%
  of all candidates.
- At least one simultaneous improvement occurs for 11/11 backbones under Model 1
  and 4/11 under Model 2. Per-backbone conditional retention ranges from
  0.0% to 78.6%.
- Mean paired changes are `Delta k = -0.576` and
  `Delta Tg = 25.8 K` under Model 1, versus
  `Delta k = -0.371` and
  `Delta Tg = -26.8 K` under Model 2.
- Baseline-subtracted changes have Pearson correlations of
  `r = 0.767` for `Delta k` and
  `r = 0.768` for `Delta Tg`.
- With the matching baseline included, aggregate Pareto retention is
  99/
  144
  (68.8%), and aggregate Jaccard similarity
  is 68.8%. Candidate-only Pareto retention (the old
  definition) is 70.1%.

## Calibration-offset test

The mean signed Model-2-minus-Model-1 shifts of the baselines are
0.266 for `k` and
-15.6 K for `Tg`. After matching and subtracting
each baseline, the mean Model-2-minus-Model-1 difference-in-differences is
0.205 for `k` and
-52.6 K for `Tg`, with mean absolute residuals of
0.212 and 52.6 K. A purely additive,
backbone-level calibration offset would cancel and leave near-zero residuals. The offset therefore
explains only part of the cross-model difference, especially for `Tg`.

## Per-backbone results

| ID | N | Mean Δk M1 | Mean Δk M2 | Mean ΔTg M1 (K) | Mean ΔTg M2 (K) | M1 both | M2 both | Retained | Pareto retention |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 19 | -0.664 | -0.345 | 41.6 | 13.1 | 17 | 6 | 35.3% | 73.7% |
| 1 | 14 | -0.493 | -0.434 | 18.0 | -49.1 | 9 | 0 | 0.0% | 57.1% |
| 2 | 8 | -0.311 | -0.263 | 10.5 | -12.3 | 6 | 1 | 16.7% | 75.0% |
| 3 | 10 | -0.453 | -0.393 | 10.2 | -52.9 | 8 | 0 | 0.0% | 80.0% |
| 4 | 18 | -0.865 | -0.325 | 40.7 | 11.1 | 17 | 13 | 76.5% | 94.4% |
| 5 | 8 | -0.808 | -0.571 | -24.2 | -83.2 | 3 | 0 | 0.0% | 87.5% |
| 6 | 8 | -0.456 | -0.457 | 1.3 | -43.2 | 5 | 0 | 0.0% | 50.0% |
| 7 | 15 | -0.669 | -0.544 | 19.6 | -74.0 | 12 | 0 | 0.0% | 53.3% |
| 8 | 12 | -0.491 | -0.439 | 20.1 | -48.7 | 11 | 0 | 0.0% | 41.7% |
| 9 | 16 | -0.351 | -0.193 | 32.0 | -37.6 | 12 | 0 | 0.0% | 56.2% |
| 10 | 16 | -0.571 | -0.260 | 55.7 | 20.0 | 14 | 11 | 78.6% | 81.2% |

## Interpretation boundary

The 31 candidates that improve both properties under both models are the defensible cross-model
robust subset. The calculation does not support a universal robustness claim for all 144
candidates, and it is not experimental or higher-fidelity physical validation. Manuscript wording
should therefore be narrowed to the retained subset and explicitly describe the remaining model
sensitivity.
