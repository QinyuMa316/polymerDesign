import pandas as pd
import numpy as np
from itertools import combinations

# =========================
# 1. 输入文件
# =========================
file_paths = [
    "groups_attr/1groups_attr.csv",
    "groups_attr/2groups_attr.csv",
    "groups_attr/3groups_attr.csv",
    # "4groups_attr.csv",
    # "5groups_attr.csv",
]

key_col = "functional groups"

# 需要评估的参数
all_cols = [
    "k_mean",
    "k_median",
    "k_IQR",
    "Tg_mean",
    "Tg_median",
    "Tg_IQR",
]

# 最终输出顺序
parameter_order = [
    "k_mean",
    "k_median",
    "k_IQR",
    "Tg_mean",
    "Tg_median",
    "Tg_IQR",
]


# =========================
# 2. 读取并合并多次运行结果
# =========================
dfs = []

for i, path in enumerate(file_paths, start=1):
    df = pd.read_csv(path)

    # 去除列名前后空格，避免匹配错误
    df.columns = df.columns.str.strip()

    # 转换数值列
    for col in df.columns:
        if col != key_col:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # 给每次运行的列加后缀
    df = df.rename(
        columns={c: f"{c}_run{i}" for c in df.columns if c != key_col}
    )

    dfs.append(df)

merged = dfs[0]
for df in dfs[1:]:
    merged = pd.merge(merged, df, on=key_col, how="inner")

print("Merged shape:", merged.shape)
print(merged.head())


# =========================
# 3. 定义统计函数
# =========================
def sign_consistency(x, y, tol=1e-12):
    """
    计算归因符号一致率。
    对 mean 和 median 有明确解释意义。
    对 IQR 来说，由于 IQR 理论上非负，因此通常会得到 1.00。
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    sx = np.where(np.abs(x) <= tol, 0, np.sign(x))
    sy = np.where(np.abs(y) <= tol, 0, np.sign(y))

    return np.mean(sx == sy)


def topk_overlap(x, y, k=5):
    """
    计算两次运行中 top-k substituent 的重合比例。
    这里按照 absolute value 排序。
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    top_x = set(np.argsort(np.abs(x))[-k:])
    top_y = set(np.argsort(np.abs(y))[-k:])

    return len(top_x & top_y) / k


def pairwise_consistency(df, col, n_runs, top_k=5):
    """
    对某一个参数计算所有运行两两之间的一致性。
    """
    records = []

    for i, j in combinations(range(1, n_runs + 1), 2):
        x = pd.to_numeric(df[f"{col}_run{i}"], errors="coerce")
        y = pd.to_numeric(df[f"{col}_run{j}"], errors="coerce")

        valid = x.notna() & y.notna()
        x_valid = x[valid]
        y_valid = y[valid]

        if len(x_valid) < 2:
            pearson = np.nan
            spearman = np.nan
            sign_acc = np.nan
            top_overlap = np.nan
        else:
            pearson = x_valid.corr(y_valid, method="pearson")
            spearman = x_valid.corr(y_valid, method="spearman")
            sign_acc = sign_consistency(x_valid, y_valid)
            top_overlap = topk_overlap(x_valid, y_valid, k=top_k)

        records.append({
            "parameter": col,
            "run_pair": f"run{i}_vs_run{j}",
            "pearson": pearson,
            "spearman": spearman,
            "sign_consistency": sign_acc,
            f"top{top_k}_overlap": top_overlap,
        })

    return pd.DataFrame(records)


# =========================
# 4. 计算 pairwise consistency
# =========================
n_runs = len(file_paths)

pairwise_list = []

for col in all_cols:
    tmp = pairwise_consistency(
        merged,
        col,
        n_runs=n_runs,
        top_k=5
    )
    pairwise_list.append(tmp)

pairwise_all = pd.concat(pairwise_list, ignore_index=True)

# 按指定顺序排序
pairwise_all["parameter"] = pd.Categorical(
    pairwise_all["parameter"],
    categories=parameter_order,
    ordered=True
)

pairwise_all = pairwise_all.sort_values(
    by=["parameter", "run_pair"]
).reset_index(drop=True)

# 确保数值列是 float
numeric_cols = [
    "pearson",
    "spearman",
    "sign_consistency",
    "top5_overlap",
]

for col in numeric_cols:
    pairwise_all[col] = pd.to_numeric(pairwise_all[col], errors="coerce")


# =========================
# 5. 计算 numeric summary
# =========================
summary_all = (
    pairwise_all
    .groupby("parameter", observed=False)
    .agg({
        "pearson": ["mean", "std"],
        "spearman": ["mean", "std"],
        "sign_consistency": ["mean", "std"],
        "top5_overlap": ["mean", "std"],
    })
)

# 展平 MultiIndex 表头
summary_all.columns = [
    f"{metric}_{stat}" for metric, stat in summary_all.columns
]

summary_all = summary_all.reset_index()

summary_all["parameter"] = pd.Categorical(
    summary_all["parameter"],
    categories=parameter_order,
    ordered=True
)

summary_all = summary_all.sort_values(
    by="parameter"
).reset_index(drop=True)

for col in summary_all.columns:
    if col != "parameter":
        summary_all[col] = pd.to_numeric(summary_all[col], errors="coerce")


# =========================
# 6. 整理成论文表格形式
# =========================
def format_mean_std(mean_value, std_value, digits=2):
    """
    格式化为 0.81±0.13 的形式。
    """
    if pd.isna(mean_value) or pd.isna(std_value):
        return ""

    return f"{mean_value:.{digits}f}±{std_value:.{digits}f}"


summary_for_paper = pd.DataFrame()

summary_for_paper["parameter"] = summary_all["parameter"].astype(str)

summary_for_paper["pearson"] = summary_all.apply(
    lambda row: format_mean_std(row["pearson_mean"], row["pearson_std"]),
    axis=1
)

summary_for_paper["spearman"] = summary_all.apply(
    lambda row: format_mean_std(row["spearman_mean"], row["spearman_std"]),
    axis=1
)

summary_for_paper["sign_consistency"] = summary_all.apply(
    lambda row: format_mean_std(row["sign_consistency_mean"], row["sign_consistency_std"]),
    axis=1
)

# 可选：如果后续想把 top5_overlap 也放进表格，取消下面注释
# summary_for_paper["top5_overlap"] = summary_all.apply(
#     lambda row: format_mean_std(row["top5_overlap_mean"], row["top5_overlap_std"]),
#     axis=1
# )


# =========================
# 7. 保存结果
# =========================
merged.to_csv(
    "merged_all_runs_attribution.csv",
    index=False,
    encoding="utf-8-sig",
    float_format="%.6f"
)

pairwise_all.to_csv(
    "pairwise_consistency_all.csv",
    index=False,
    encoding="utf-8-sig",
    float_format="%.6f"
)

summary_all.to_csv(
    "summary_consistency_all_numeric.csv",
    index=False,
    encoding="utf-8-sig",
    float_format="%.6f"
)

summary_for_paper.to_csv(
    "summary_consistency_for_paper.csv",
    index=False,
    encoding="utf-8-sig"
)

# 同时保存为 Excel，推荐用这个复制到论文表格
with pd.ExcelWriter("result3/attribution_consistency_results.xlsx", engine="openpyxl") as writer:
    merged.to_excel(writer, sheet_name="merged_all_runs", index=False)
    pairwise_all.to_excel(writer, sheet_name="pairwise_all", index=False)
    summary_all.to_excel(writer, sheet_name="summary_numeric", index=False)
    summary_for_paper.to_excel(writer, sheet_name="summary_for_paper", index=False)


# =========================
# 8. 打印结果
# =========================
print("\n=== Pairwise consistency all ===")
print(pairwise_all)

print("\n=== Summary consistency all, numeric ===")
print(summary_all)

print("\n=== Summary consistency for paper ===")
print(summary_for_paper)

print("\nFiles saved:")
print("merged_all_runs_attribution.csv")
print("pairwise_consistency_all.csv")
print("summary_consistency_all_numeric.csv")
print("summary_consistency_for_paper.csv")
print("attribution_consistency_results.xlsx")