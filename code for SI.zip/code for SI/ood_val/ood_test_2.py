import os
import numpy as np
import pandas as pd
import torch
from torch_geometric.data import DataLoader
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from rdkit import Chem, DataStructs
from rdkit.Chem import rdFingerprintGenerator
from MolOpt.molDataLoader import MolDataset
from MolOpt.GATmodel import GATModel


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def build_model():
    return GATModel(num_node_features=7, num_edge_features=6, hidden_dim=128, num_heads=4, dropout=0.2, num_layers=3)


def load_model(target="Tg"):
    suffix = "_cl_50epo_aug12"
    mdl_path = f"models_polymer/best_model_{target}{suffix}.pth"

    model = build_model()
    chkpt = torch.load(mdl_path, map_location=device)
    model.load_state_dict(chkpt["model_state_dict"])
    model.to(device).eval()

    return model


def predict_property(smiles_list, model, batch_size=64):
    ds = MolDataset(smiles_list, [0] * len(smiles_list))
    dl = DataLoader(ds, batch_size=batch_size, shuffle=False)

    preds = []

    with torch.no_grad():
        for batch in dl:
            out, _ = model(batch.to(device))
            preds.extend(out.detach().cpu().view(-1).numpy().tolist())

    return np.asarray(preds, dtype=float)


def mol_from_smiles(smiles):
    if pd.isna(smiles):
        return None

    try:
        return Chem.MolFromSmiles(str(smiles))
    except Exception:
        return None


def calculate_max_tanimoto(train_smiles, test_smiles, radius=2, fp_size=2048):
    """
    对每个测试分子计算其与训练集中所有分子的最大 Morgan-Tanimoto similarity。

    MaxSimilarity 越低，说明该测试分子越远离训练集。
    """
    fp_generator = rdFingerprintGenerator.GetMorganGenerator(radius=radius, fpSize=fp_size)

    train_fps = []
    for smiles in train_smiles:
        mol = mol_from_smiles(smiles)
        if mol is not None:
            train_fps.append(fp_generator.GetFingerprint(mol))

    if len(train_fps) == 0:
        raise ValueError("No valid SMILES were found in the training dataset.")

    max_similarities = []

    for smiles in test_smiles:
        mol = mol_from_smiles(smiles)

        if mol is None:
            max_similarities.append(np.nan)
            continue

        fp = fp_generator.GetFingerprint(mol)
        similarities = DataStructs.BulkTanimotoSimilarity(fp, train_fps)
        max_similarities.append(max(similarities))

    return np.asarray(max_similarities, dtype=float)


def calculate_metrics(y_true, y_pred):
    return {
        "N": len(y_true),
        "R2": r2_score(y_true, y_pred),
        "MAE": mean_absolute_error(y_true, y_pred),
        "RMSE": np.sqrt(mean_squared_error(y_true, y_pred))
    }


if __name__ == "__main__":

    target = "Tg"
    ood_fraction = 0.50
    print(f'Target property: {target}, OOD fraction: {ood_fraction:.0%}')

    # 1. 读取训练集和外部测试集
    train_file = "polyDesign_data/data_train/Tg_combined_unique.csv"
    test_file = "polyDesign_data/data_train_add/Tg2_processed.csv"

    train_df = pd.read_csv(train_file)
    test_df = pd.read_csv(test_file)

    if "SMILES" not in train_df.columns or "SMILES" not in test_df.columns:
        raise ValueError("Both datasets must contain a 'SMILES' column.")

    if target not in test_df.columns:
        raise ValueError(f"Test dataset must contain the target column '{target}'.")

    # 删除测试集中没有实验标签的样本
    test_df = test_df.dropna(subset=["SMILES", target]).reset_index(drop=True)

    # 2. Morgan fingerprint + Tanimoto similarity，对每个测试样本计算它与训练集的最大结构相似度

    test_df["MaxTrainTanimoto"] = calculate_max_tanimoto(train_df["SMILES"].tolist(), test_df["SMILES"].tolist())

    # 删除无法生成 fingerprint 的无效 SMILES
    test_df = test_df.dropna(subset=["MaxTrainTanimoto"]).reset_index(drop=True)


    # 3. 定义 OOD-like subset，最大训练集相似度最低的 20%
    similarity_threshold = test_df["MaxTrainTanimoto"].quantile(ood_fraction)

    test_df["OOD_like"] = test_df["MaxTrainTanimoto"] <= similarity_threshold
    ood_df = test_df[test_df["OOD_like"]].copy().reset_index(drop=True)


    # 4. 加载预测模型
    model = load_model(target)


    # 5. 对整个外部测试集预测
    test_df[f"{target}_Pred"] = predict_property(test_df["SMILES"].tolist(), model)


    # 6. 对 OOD-like subset 提取对应预测值
    ood_df = test_df[test_df["OOD_like"]].copy().reset_index(drop=True)

    # 7. 计算整个外部测试集性能
    y_test = test_df[target].astype(float).to_numpy()
    pred_test = test_df[f"{target}_Pred"].astype(float).to_numpy()
    overall_metrics = calculate_metrics(y_test, pred_test)

    # 8. 计算 OOD-like subset 性能
    y_ood = ood_df[target].astype(float).to_numpy()
    pred_ood = ood_df[f"{target}_Pred"].astype(float).to_numpy()
    ood_metrics = calculate_metrics(y_ood, pred_ood)

    # 9. 保存结果
    output_dir = "ood_evaluation"
    os.makedirs(output_dir, exist_ok=True)

    test_df.to_csv(f"{output_dir}/{target}_external_test_with_similarity.csv", index=False, encoding="utf-8-sig")
    ood_df.to_csv(f"{output_dir}/{target}_OOD_like_subset.csv", index=False, encoding="utf-8-sig")

    metrics_df = pd.DataFrame([
        {
            "Dataset": "External test set",
            "N": overall_metrics["N"],
            "SimilarityCriterion": "All samples",
            "R2": overall_metrics["R2"],
            "MAE": overall_metrics["MAE"],
            "RMSE": overall_metrics["RMSE"]
        },
        {
            "Dataset": "OOD-like subset",
            "N": ood_metrics["N"],
            "SimilarityCriterion": f"Lowest {ood_fraction:.0%} by maximum training-set Tanimoto similarity",
            "R2": ood_metrics["R2"],
            "MAE": ood_metrics["MAE"],
            "RMSE": ood_metrics["RMSE"]
        }
    ])

    metrics_df.to_csv(f"{output_dir}/{target}_OOD_metrics.csv", index=False, encoding="utf-8-sig")

    # 10. 输出关键结果
    print(f"Total external test samples: {len(test_df)}")
    print(f"OOD-like samples: {len(ood_df)}")
    print(f"{int(ood_fraction * 100)}th-percentile similarity threshold: {similarity_threshold:.4f}")

    print("\nExternal test set:")
    print(f"R2   = {overall_metrics['R2']:.4f}")
    print(f"MAE  = {overall_metrics['MAE']:.4f}")
    print(f"RMSE = {overall_metrics['RMSE']:.4f}")

    print("\nOOD-like subset:")
    print(f"R2   = {ood_metrics['R2']:.4f}")
    print(f"MAE  = {ood_metrics['MAE']:.4f}")
    print(f"RMSE = {ood_metrics['RMSE']:.4f}")


    """
    Target property: Tg, OOD fraction: 50%
    Total external test samples: 6815
    OOD-like samples: 3413
    50th-percentile similarity threshold: 0.4314

    External test set:
    R2   = 0.3795
    MAE  = 64.3994
    RMSE = 85.5749

    OOD-like subset:
    R2   = -0.0713
    MAE  = 68.7225
    RMSE = 92.9747
    """
